
v1.0 release
------------

Website URL: https://www.ebi.ac.uk/metagenomics/genome-catalogues/maize-rhizosphere-v1-0

* A total of 431 prokaryotic genomes from the maize rhizosphere microbiome were clustered into 336 species representatives.
* Genomes from the following studies were used to generate the catalogue: ERP020742, ERP022857, ERP157559, ERP157561, ERP158283, ERP174695, ERP174731, ERP174743, ERP177062, ERP177178, ERP177216, ERP177291, ERP177365, ERP177775, ERP177792, ERP177813, ERP177895, ERP178644, PRJNA1013142, PRJNA1120117, PRJNA1134685, PRJNA1152787, PRJNA1158327, PRJNA1187345, PRJNA1199329, PRJNA1201591, PRJNA1229146, PRJNA1250159, PRJNA202950, PRJNA208966, PRJNA258365, PRJNA315684, PRJNA388288, PRJNA400804, PRJNA432357, PRJNA432947, PRJNA470606, PRJNA480899, PRJNA495000, PRJNA506148, PRJNA507554, PRJNA544897, PRJNA577420, PRJNA579457, PRJNA580229, PRJNA614623, PRJNA645088, PRJNA681194, PRJNA701893, PRJNA756835, PRJNA773181, PRJNA841055, PRJNA84283, PRJNA849335, PRJNA891937, PRJNA910835, PRJNA938964, PRJNA970469, SRP147978, SRP148117, SRP153035, SRP156928, SRP184254, SRP184278, SRP184634, SRP202000, SRP255781, SRP323385, SRP330606, SRP330682, SRP330969, SRP332265, SRP377750, SRP392491, SRP457426, SRP459203, SRP460637, SRP486796, SRP499691, SRP503830, SRP510833, SRP520132, SRP545786, SRP568450
* The catalogue was generated using MGnify genomes pipeline v2.5.0: https://github.com/EBI-Metagenomics/genomes-catalogue-pipeline/releases/tag/v2.5.0. 
* A protein catalogue was produced with all protein coding sequences clustered at 100%, 95%, 90% and 50% amino acid identity.
* A gene catalogue is the collection of nucleotide sequences corresponding to the protein cluster representatives of the 100% identity clustering. 


## The following files are available for download for the species representative in each species directory within the species_catalogue/ folder:

- genome/
    * [species_accession]_amrfinderplus.tsv : AMR annotations produced by AMRFinderPlus.
    * [species_accession]_annotation_coverage.tsv : A summary of annotation coverage.
    * [species_accession]_antismash.gff : AntiSMASH output file containing biosynthetic gene cluster information.
    * [species_accession]_cazy_summary.tsv : CAZy summary parsed from the eggNOG annotation file.
    * [species_accession]_cog_summary.tsv : COG summary parsed from the eggNOG annotation file.
    * [species_accession]_crisprcasfinder.gff : Unfiltered CRISPRCasFinder results file, including calls that have evidence level 1 and are less likely to be genuine.
    * [species_accession]_crisprcasfinder.tsv : Additional data for CRISPRCasFinder records reported in [species_accession]_crisprcasfinder.gff.
    * [species_accession]_dbcan.gff : dbCAN annotation file containing putative polysaccharide utilisation loci, predicted substrates and functions of member genes.
    * [species_accession]_defense_finder.gff : Anti-phage and anti-defense system annotations.
    * [species_accession]_eggNOG.tsv : eggNOG annotations of the protein coding sequences.
    * [species_accession].faa : Protein sequence FASTA file of the species representative.
    * [species_accession].fna : DNA sequence FASTA file of the genome assembly of the species representative.
    * [species_accession].fna.fai : A samtools-generated index of the genome assembly FASTA file.
    * [species_accession].gff : Genome GFF file with various sequence annotations, including InterPro, eggNOG, Pfam, KEGG, COG, ncRNAs, CRISPR (filtered results with evidence level >= 2), mobilome and viral annotations, biosynthetic gene clusters, antimicrobial resistance genes, putative polysaccharide utilisation loci, anti-phage and anti-defense systems.
    * [species_accession]_InterProScan.tsv : InterProScan annotation of the protein coding sequences.
    * [species_accession]_kegg_classes.tsv : KEGG classes and their counts.
    * [species_accession]_kegg_modules.tsv : KEGG modules and their counts.
    * [species_accession]_kegg_pathways.tsv : KEGG pathway completeness.
    * [species_accession]_mobilome.gff : Annotated viral sequence and mobile elements.
    * [species_accession]_rRNAs.fasta : rRNA sequence FASTA file.
    * [species_accession]_sanntis.gff : SanntiS output file containing biosynthetic gene cluster information.


## For species where there is more than one conspecific genome, pan-genomes can be found in:
       
- pan-genome/
    * core_genes.txt : List of core genes for the pan-genome (genes found in >=90% of the genomes).
    * pan-genome.fna : Nucleotide sequence FASTA file of the pan-genome.
    * gene_presence_absence.csv: A list of genes in the pan-genome with their annotation and MGYG accessions.
    * gene_presence_absence.Rtab : Presence/absence binary matrix of the pan-genome across all conspecific genomes.
    * mashtree.nwk : Tree generated from the pairwise Mash distances of conspecific genomes.


## Additional files available in the parent directory:

- all_genomes.msh : A Mash sketch of all 431 genomes.

- all_genomes/ : Combined GFF/FASTA file (Prokka output) for each of the 431 genomes. For species representative genomes, the GFF contains additional annotations as described above.  
       
- gene_catalogue/: 
    * gene_catalogue-100.ffn.gz : Nucleotide sequences corresponding to the protein cluster representatives in the protein catalogue clustered at 100% amino acid identity.
    * clusters.tsv : A list of gene accession pairs where the first accession is that of a gene included in the gene catalogue as the representative and the second is a gene that is not included in the gene catalogue but belongs in the same cluster based on amino acid identity.

- genomes-all_metadata.tsv : Assembly statistics and metadata of all 431 genomes. 

- kraken2_db_maize-rhizosphere_v1.0/ : A folder containing the Kraken 2 and Bracken databases. 

- pangenome_functions/ (data generated by the BioSIFTR pipeline v1.2.1 https://github.com/EBI-Metagenomics/biosiftr) :
    * functional_profiles.tar.gz : Collection of tables, one file per species cluster, containing the KEGG orthologues, Pfam, and CAZy annotations per gene at the pangenome level. Each gene is labelled as core true or false.
    * kegg_completeness.tar.gz : Collection of tables, one file per species cluster, containing the KEGG modules completeness which is calculated separately for the whole pangenome and for the core genes only.

- phylogenies/: 
    * ar53_iqtree.nwk : A phylogenetic tree for archaeal genomes in Newick format.
    * bac120_iqtree.nwk : A phylogenetic tree for bacterial genomes in Newick format.
    * ar53_alignment.faa.gz : A multiple sequence alignment for archaeal genomes.
    * bac120_alignment.faa.gz : A multiple sequence alignment for bacterial genomes.

- protein_catalogue/
    * protein_catalogue-XX.tar.gz
        - protein_catalogue-XX.faa : Protein FASTA file of the clustered, representative sequences.
        - protein_catalogue-XX.tsv : Cluster membership of all the protein sequences.
    For 90% identity catalogue only:
        - protein_catalogue-90_eggNOG.tsv : eggNOG annotation results of the protein catalogue.
        - protein_catalogue-90_InterProScan.tsv : InterProScan annotation results of the protein catalogue.
    
- sourmash_db_maize-rhizosphere-v1-0/ (data generated by the BioSIFTR pipeline v1.2.1 https://github.com/EBI-Metagenomics/biosiftr) :
    * sourmash_species_representatives_k21.sbt.zip : Sourmash database for representative genomes using kmer = 21.

